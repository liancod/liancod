/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pryctofinalticketmaster;

/**
 *
 * @author MATT
 */
public class PryctoFinalTicketMaster {

    public static void main(String[] args) {
        System.out.println("Ganas de matarme");
    }
}
