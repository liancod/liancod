/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.ConceptosController;
import controller.DetalleVentasController;
import controller.FuncionesController;
import controller.VendedoresController;
import controller.VentasController;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.DetalleVentas;
import model.Funciones;
import model.Vendedores;
import model.Ventas;

/**
 *
 * @author MATT
 */
public class FrmPrincipal extends javax.swing.JFrame {
    DefaultTableModel dtmFunciones = new DefaultTableModel();
    DefaultTableModel dtmFuncElegidos = new DefaultTableModel();
    
    DetalleVentasController detallesController = new DetalleVentasController();
    VentasController ventasController = new VentasController();
    
    VendedoresController vendedorController = new VendedoresController();
    ConceptosController conceptosController = new ConceptosController();
    FuncionesController funcionesController = new FuncionesController();
    
    
    
    /**
     * Creates new form FrmParaVender
     */
    public FrmPrincipal() {
        initComponents();
        
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Vendiendo...");
        
        llenarColumnasFunciones();
        listarListaFunciones();
        llenarColumnasFuncElegidos();
        llenaComboIDYNombreVendedores();
        inicializarFechaActual();
        
        
    }
    
    public void inicializarFechaActual() {
        //Esto es para obtener la fecha actual y asignarla a txtFecha
        LocalDate fechaActual = LocalDate.now();
        //Formatear la fecha en el formato deseado (year-month-day)
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String fechaFormateada = fechaActual.format(formatter);
        //Asignar la fecha formateada a txtFecha
        txtFecha.setText(fechaFormateada);
    }
    
   
    private void llenarColumnasFunciones()
    {
        
        //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
        dtmFunciones.addColumn("ID_FUNCION");
        dtmFunciones.addColumn("ID_CONCEPTO");
        dtmFunciones.addColumn("CONCEPTO_NOMBRE");
        dtmFunciones.addColumn("NOMBRE_FUNCION");
        dtmFunciones.addColumn("ID_TIPO");
        dtmFunciones.addColumn("TIPO_NOMBRE");
        dtmFunciones.addColumn("LUGAR_FUNCION");
        dtmFunciones.addColumn("FECHA_FUNCION");
        dtmFunciones.addColumn("DISPONIBILIDAD");
        dtmFunciones.addColumn("PRECIO");
        this.tableFunciones.setModel(dtmFunciones);
    }
    
    private void llenarColumnasFuncElegidos()
    {
        
        //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
        dtmFuncElegidos.addColumn("ID_FUNCION");
        dtmFuncElegidos.addColumn("ID_CONCEPTO");
        dtmFuncElegidos.addColumn("CONCEPTO_NOMBRE");
        dtmFuncElegidos.addColumn("NOMBRE_FUNCION");
        dtmFuncElegidos.addColumn("ID_TIPO");
        dtmFuncElegidos.addColumn("TIPO_NOMBRE");
        dtmFuncElegidos.addColumn("LUGAR_FUNCION");
        dtmFuncElegidos.addColumn("FECHA_FUNCION");
        dtmFuncElegidos.addColumn("PRECIO");
        dtmFuncElegidos.addColumn("CANTIDAD");
        dtmFuncElegidos.addColumn("SUBTOTAL");
        this.tableFuncionesElegidos.setModel(dtmFuncElegidos);
    }
       
    
    public void listarListaFunciones()
    {
        //idConcepto, concepto_nombre, idTipo
        List<Funciones> lst = funcionesController.getAllFuncionesController();
        dtmFunciones.setNumRows(0);
        
        // Agregar las filas actualizadas al modelo de la tabla
        for (Funciones x : lst) {
            //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
            Object[] vector = new Object[10];
            vector[0] = x.getIdFuncion();
            vector[1] = x.getIdConcepto();
            vector[2] = x.getConceptoNombre();
            vector[3] = x.getNombreFuncion();
            vector[4] = x.getIdTipos();
            vector[5] = x.getTipoNombre();
            vector[6] = x.getLugarFuncion();
            vector[7] = x.getDisponibleFuncion();
            vector[8] = x.getFechaFuncion();
            vector[9] = x.getPrecio();           

            dtmFunciones.addRow(vector);
        }

        // Establecer el modelo actualizado en la tabla
       tableFunciones.setModel(dtmFunciones);
    }
    
    public void listarListaFuncElegidos(int eve)
    {
        try {
            // idConcepto, concepto_nombre, idTipo
            Funciones obj = new Funciones();
            obj.setIdFuncion(eve);
            List<Funciones> lst = funcionesController.getFuncionesPorIdController(obj);

            String disponibilidad = "Disponible";

            // Buscar si la función ya está en la tabla
            int filaExistente = -1;
            for (int fila = 0; fila < dtmFuncElegidos.getRowCount(); fila++) {
                int idFuncionExistente = (int) dtmFuncElegidos.getValueAt(fila, 0);
                if (idFuncionExistente == eve) {
                    filaExistente = fila;
                    break;
                }
            }

            // Si la funcion ya está en la tabla, actualizaa la cantidad
            if (filaExistente != -1) {
                int nuevaCantidad = Integer.parseInt(txtCantidad.getText());
                int cantidadExistente = (int) dtmFuncElegidos.getValueAt(filaExistente, 9);
                double precioUnitario = (double) dtmFuncElegidos.getValueAt(filaExistente, 8);
                double nuevoSubtotal = precioUnitario * (cantidadExistente + nuevaCantidad);

                // Actualizar la cantidad y el subtotal en la fila existente
                dtmFuncElegidos.setValueAt(cantidadExistente + nuevaCantidad, filaExistente, 9);
                dtmFuncElegidos.setValueAt(nuevoSubtotal, filaExistente, 10);
            } else {
                // Agregar una nueva fila si la funcion no esta en la tabla
                for (Funciones x : lst) {
                    if (x.getDisponibleFuncion().equals(disponibilidad)) {
                        int cantidad = Integer.parseInt(txtCantidad.getText());
                        double subtotal = x.getPrecio() * cantidad;

                        Object[] vector = new Object[11];
                        vector[0] = x.getIdFuncion();
                        vector[1] = x.getIdConcepto();
                        vector[2] = x.getConceptoNombre();
                        vector[3] = x.getNombreFuncion();
                        vector[4] = x.getIdTipos();
                        vector[5] = x.getTipoNombre();
                        vector[6] = x.getLugarFuncion();
                        vector[7] = x.getFechaFuncion();
                        vector[8] = x.getPrecio();
                        vector[9] = cantidad;
                        vector[10] = subtotal;

                        dtmFuncElegidos.addRow(vector);
                    } else {
                        JOptionPane.showMessageDialog(this, "Función no disponible");
                    }
                }
            }

            // Establecer el modelo actualizado en la tabla
            tableFuncionesElegidos.setModel(dtmFuncElegidos);
        } catch (Exception e) {
            e.getMessage();
            JOptionPane.showMessageDialog(this, "Seleccione la cantidad");
        }
    }
    
    public void llenaComboIDYNombreVendedores()
    {
        List<Vendedores> lst = vendedorController.getAllVendedoresController();
        for(Vendedores x: lst)
        {
            this.cboIdYNombreVendedor.addItem(x.getIdVendedores()+ " " + x.getNombreVendedores());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtFecha = new javax.swing.JTextField();
        btnGenerarVenta = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        btnEliminarFuncionElegida = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtDniCliente = new javax.swing.JTextField();
        txtIdVenta = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableFunciones = new javax.swing.JTable();
        cboIdYNombreVendedor = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableFuncionesElegidos = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnEnviarALogin = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtFecha.setEditable(false);
        txtFecha.setBackground(new java.awt.Color(255, 255, 255));
        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });
        jPanel1.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 238, -1));

        btnGenerarVenta.setBackground(new java.awt.Color(204, 204, 204));
        btnGenerarVenta.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnGenerarVenta.setForeground(new java.awt.Color(0, 0, 0));
        btnGenerarVenta.setText("GENERAR VENTA");
        btnGenerarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarVentaActionPerformed(evt);
            }
        });
        jPanel1.add(btnGenerarVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 565, 140, -1));

        jLabel10.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel10.setText("Nombre de Cliente:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(339, 10, -1, -1));

        jLabel11.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel11.setText("DNI de Cliente:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(339, 39, -1, -1));

        jLabel2.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel2.setText("Id de Venta:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 9, -1, -1));

        txtNombreCliente.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 10, 238, -1));

        btnEliminarFuncionElegida.setBackground(new java.awt.Color(204, 204, 204));
        btnEliminarFuncionElegida.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnEliminarFuncionElegida.setForeground(new java.awt.Color(0, 0, 0));
        btnEliminarFuncionElegida.setText("Eliminar");
        btnEliminarFuncionElegida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarFuncionElegidaActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminarFuncionElegida, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 40, -1, -1));

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel3.setText("Encargado:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 37, -1, -1));

        txtDniCliente.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtDniCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, 238, -1));

        txtIdVenta.setEditable(false);
        txtIdVenta.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtIdVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 6, 205, -1));

        tableFunciones.setBackground(new java.awt.Color(204, 204, 204));
        tableFunciones.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tableFunciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableFunciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableFuncionesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableFunciones);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 174, 1006, 147));

        cboIdYNombreVendedor.setBackground(new java.awt.Color(204, 204, 204));
        cboIdYNombreVendedor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(cboIdYNombreVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 34, 205, -1));

        jLabel7.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel7.setText("Cantidad:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 72, -1, -1));

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("LISTA DE EVENTOS");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(448, 140, 127, 22));

        txtCantidad.setBackground(new java.awt.Color(255, 255, 255));
        txtCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadActionPerformed(evt);
            }
        });
        jPanel1.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 69, 205, -1));

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("EVENTOS ELEGIDOS");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 339, -1, -1));

        btnNuevo.setBackground(new java.awt.Color(204, 204, 204));
        btnNuevo.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 0, 0));
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel1.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 10, 73, -1));

        tableFuncionesElegidos.setBackground(new java.awt.Color(204, 204, 204));
        tableFuncionesElegidos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tableFuncionesElegidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tableFuncionesElegidos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 373, 1272, 180));

        jLabel9.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel9.setText("Fecha:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(339, 68, -1, -1));

        jLabel12.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel12.setText("TOTAL");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 570, -1, -1));

        txtTotal.setBackground(new java.awt.Color(204, 204, 204));
        txtTotal.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(0, 0, 0));
        txtTotal.setText("0.0");
        jPanel1.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(1171, 565, 107, -1));

        jLabel1.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel1.setText("Ingreso de Administrador");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 10, -1, -1));

        btnEnviarALogin.setBackground(new java.awt.Color(204, 204, 204));
        btnEnviarALogin.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnEnviarALogin.setForeground(new java.awt.Color(0, 0, 0));
        btnEnviarALogin.setText("Administrador");
        btnEnviarALogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarALoginActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnviarALogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 30, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\beath\\OneDrive\\Documents\\NetBeansProjects\\pryctoFinalTicketMaster\\src\\main\\java\\util\\windowsXPfondo.jpg")); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1290, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadActionPerformed
        
    }//GEN-LAST:event_txtCantidadActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        //Obtener el último id
        int ultimoId = ventasController.getUltimoIdVentaController();

        //aumentar 1 al ultimo id para el nuevo id
        int nuevoId = ultimoId + 1;

        //Establecer el nuevo ID en el campo de texto
        txtIdVenta.setText(String.valueOf(nuevoId));
        txtCantidad.setText("");
        txtNombreCliente.setText("");
        txtDniCliente.setText("");
        //txtTotal.setText("");

        //deseleccionar cualquier fila que esté seleccionada en la tabla
        //tableDetalle.clearSelection();
        inicializarFechaActual();
    }//GEN-LAST:event_btnNuevoActionPerformed
    
    public void CalculoTotal()
    {
        double sumaSubtotales = 0.0;
        int columnaSubtotal = 10; // Índice de la última columna (considerando que las columnas se indexan desde 0)
        for (int fila = 0; fila < dtmFuncElegidos.getRowCount(); fila++) {
            double subtotal = (double) dtmFuncElegidos.getValueAt(fila, columnaSubtotal);
            sumaSubtotales += subtotal;
        }

        // Mostrar la suma en el TextField TOTAL
        txtTotal.setText(String.valueOf(sumaSubtotales));
    }
    
    
    
    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaActionPerformed

    private void tableFuncionesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableFuncionesMouseClicked
        listarListaFuncElegidos(Integer.parseInt(tableFunciones.getValueAt(tableFunciones.getSelectedRow(), 0).toString())); //obtiene como parametro los valores del Id de Funcion
        CalculoTotal();
        txtCantidad.setText("");
    }//GEN-LAST:event_tableFuncionesMouseClicked

    private void btnGenerarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarVentaActionPerformed
        
        int msg = JOptionPane.showConfirmDialog(btnGenerarVenta,"Deseas Generar la Venta?","Grabar",JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_OPTION)
        {        
            //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
            Ventas venta = new Ventas();         
            // Obtener el elemento seleccionado del ComboBox
            if (cboIdYNombreVendedor.getSelectedItem() == null || txtNombreCliente.getText().isEmpty() || txtDniCliente.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Salir del método si hay campos sin completar
            }
            String selectedValue = cboIdYNombreVendedor.getSelectedItem().toString();
            // Dividir el valor seleccionado en ID y nombre del vendedor
            String[] parts = selectedValue.split(" ");
            
            try
            {
                if (tableFuncionesElegidos.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Por favor, elige al menos una función.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Salir del método si no hay funciones elegidas
                }
                for (int fila = 0; fila < tableFuncionesElegidos.getModel().getRowCount(); fila++) {
                    DetalleVentas detalle = new DetalleVentas();
                    
                    detalle.setIdVenta(Integer.parseInt(this.txtIdVenta.getText()));   
                    detalle.setFechaDeVenta(Date.valueOf(this.txtFecha.getText()));
                    detalle.setNombreVendedores(parts[1]);
                    detalle.setIdVendedores(Integer.parseInt(parts[0]));
                    detalle.setNombreCliente(this.txtNombreCliente.getText());
                    detalle.setDniCliente(this.txtDniCliente.getText());            
                    detalle.setIdFuncion((int)tableFuncionesElegidos.getValueAt(fila,0));
                    detalle.setIdConcepto((int)tableFuncionesElegidos.getValueAt(fila,1));        
                    detalle.setConceptoNombre((String)tableFuncionesElegidos.getValueAt(fila,2));
                    detalle.setNombreFuncion((String)tableFuncionesElegidos.getValueAt(fila,3));
                    detalle.setPrecio((double)tableFuncionesElegidos.getValueAt(fila,8));    
                    detalle.setCantidad((int)tableFuncionesElegidos.getValueAt(fila,9));
                    detalle.setTotalAPagar((double)tableFuncionesElegidos.getValueAt(fila,10));
                                 
                    detallesController.addDetalleVentaController(detalle);
                }
            }catch(Exception e)
            {
                e.getMessage();                 
            }
             
            //ESTO ES PARA VENTAS
            venta.setIdVenta(Integer.parseInt(this.txtIdVenta.getText()));
            venta.setIdVendedores(Integer.parseInt(parts[0]));
            venta.setNombreVendedor(parts[1]);
            venta.setTotalAPagar(Double.parseDouble(this.txtTotal.getText()));
            venta.setFechaDeVenta(Date.valueOf(this.txtFecha.getText()));
            ventasController.addVentaController(venta); //aqui se agrega a la tabla venta
            JOptionPane.showMessageDialog(this, "Venta generada satisfactoriamente");
        }
        dispose();
        FrmFactura factura = new FrmFactura(Integer.parseInt(this.txtIdVenta.getText()));
        factura.setVisible(true);
    }//GEN-LAST:event_btnGenerarVentaActionPerformed

    private void btnEliminarFuncionElegidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarFuncionElegidaActionPerformed
        int filaSeleccionada = tableFuncionesElegidos.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Eliminar la fila seleccionada
            dtmFuncElegidos.removeRow(filaSeleccionada);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEliminarFuncionElegidaActionPerformed

    private void btnEnviarALoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarALoginActionPerformed
        dispose();
        Login login = new Login();
        login.setVisible(true);
    }//GEN-LAST:event_btnEnviarALoginActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminarFuncionElegida;
    private javax.swing.JButton btnEnviarALogin;
    private javax.swing.JButton btnGenerarVenta;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cboIdYNombreVendedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tableFunciones;
    private javax.swing.JTable tableFuncionesElegidos;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtDniCliente;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIdVenta;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
