/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.DetalleVentasController;
import controller.VendedoresController;
import controller.VentasController;
import java.sql.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.DetalleVentas;
import model.Vendedores;
import model.Ventas;

/**
 *
 * @author MATT
 */
public class FrmVentas extends javax.swing.JFrame {

    VentasController ventasController = new VentasController();
    DetalleVentasController  detalleVenController = new DetalleVentasController();
    VendedoresController vendedorController = new VendedoresController();
    
    DefaultTableModel dtmVentas = new DefaultTableModel();
    DefaultTableModel dtmDetalles = new DefaultTableModel();
    
    private String nombreUsuario;
    /**
     * Creates new form FrmVentas
     */
    public FrmVentas(String nombreUsuario) {
        initComponents();
        
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Formulario de Ventas");
        
        this.nombreUsuario = nombreUsuario;
        columnaListaDeVentas();
        listarListaDeVentas();
        llenaComboIDNombreVendedor();
        columnaListaDetalles();
    }
    
    public void listarDetalleVentas(int idV) 
    {
        DetalleVentas obj = new DetalleVentas();
        obj.setIdVenta(idV);
        //idConcepto, concepto_nombre, idTipo
        List<DetalleVentas> lst = detalleVenController.getDetalleVentasPorIdController(obj);
        dtmDetalles.setNumRows(0);
        
        // Agregar las filas actualizadas al modelo de la tabla
        for (DetalleVentas x : lst) {
            //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
            Object[] vector = new Object[13];
            vector[0] = x.getIdVenta();
            vector[1] = x.getIdFuncion();
            vector[2] = x.getNombreFuncion();
            vector[3] = x.getIdConcepto();
            vector[4] = x.getConceptoNombre();
            vector[5] = x.getPrecio();
            vector[6] = x.getIdVendedores();
            vector[7] = x.getNombreVendedores();
            vector[8] = x.getCantidad();
            vector[9] = x.getTotalAPagar();
            vector[10] = x.getNombreCliente();
            vector[11] = x.getDniCliente();
            vector[12] = x.getFechaDeVenta();

            dtmDetalles.addRow(vector);
        }

        // Establecer el modelo actualizado en la tabla
        tableDetalle.setModel(dtmDetalles);
    }
    
    public void columnaListaDetalles()
    {
        //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
        dtmDetalles.addColumn("ID_VENTA");
        dtmDetalles.addColumn("ID_FUNCION");
        dtmDetalles.addColumn("NOMBRE_FUNCION");
        dtmDetalles.addColumn("ID_CONCEPTO");
        dtmDetalles.addColumn("NOMBRE_CONCEPTO");
        dtmDetalles.addColumn("PRECIO");
        dtmDetalles.addColumn("ID_VENDEDOR");
        dtmDetalles.addColumn("NOMBRE_VENDEDOR");
        dtmDetalles.addColumn("CANTIDAD");
        dtmDetalles.addColumn("SUBTOTAL");
        dtmDetalles.addColumn("NOMBRE_CLIENTE");
        dtmDetalles.addColumn("DNI_CLIENTE");
        dtmDetalles.addColumn("FECHA_VENTA");
        this.tableDetalle.setModel(dtmDetalles);
    }
    
    public void columnaListaDeVentas()
    {
        //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
        dtmVentas.addColumn("Id de Venta");
        dtmVentas.addColumn("ID de Vendedor");
        dtmVentas.addColumn("Nombre de Vendedor");
        dtmVentas.addColumn("Total A Pagar");
        dtmVentas.addColumn("Fecha de Venta");
        this.tableVentas.setModel(dtmVentas);
    }
    
    
    public void listarListaDeVentas()
    {
        //idConcepto, concepto_nombre, idTipo
        List<Ventas> lst = ventasController.getAllVentasController();
        dtmVentas.setNumRows(0);
        
        // Agregar las filas actualizadas al modelo de la tabla
        for (Ventas x : lst) {
            //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
            Object[] vector = new Object[5];
            vector[0] = x.getIdVenta();
            vector[1] = x.getIdVendedores();
            vector[2] = x.getNombreVendedor();
            vector[3] = x.getTotalAPagar();
            vector[4] = x.getFechaDeVenta();

            dtmVentas.addRow(vector);
        }

        // Establecer el modelo actualizado en la tabla
        tableVentas.setModel(dtmVentas);
    }
    
    public void llenaComboIDNombreVendedor()
    {
        List<Vendedores> lst = vendedorController.getAllVendedoresController();
        for(Vendedores x: lst)
        {
            this.cboIdYNombreVendedor.addItem(x.getIdVendedores()+ " " + x.getNombreVendedores());
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txtTotalAPagar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtFechaDeVenta = new javax.swing.JTextField();
        txtIdVenta = new javax.swing.JTextField();
        cboIdYNombreVendedor = new javax.swing.JComboBox<>();
        btnAgregar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableDetalle = new javax.swing.JTable();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableVentas = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtTotalAPagar.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtTotalAPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 325, -1));

        jLabel1.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel1.setText("ID de Venta:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        txtFechaDeVenta.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtFechaDeVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 325, -1));

        txtIdVenta.setEditable(false);
        txtIdVenta.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtIdVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 324, -1));

        cboIdYNombreVendedor.setBackground(new java.awt.Color(255, 255, 255));
        cboIdYNombreVendedor.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboIdYNombreVendedorItemStateChanged(evt);
            }
        });
        cboIdYNombreVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboIdYNombreVendedorActionPerformed(evt);
            }
        });
        jPanel2.add(cboIdYNombreVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 325, -1));

        btnAgregar.setBackground(new java.awt.Color(204, 204, 204));
        btnAgregar.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnAgregar.setForeground(new java.awt.Color(0, 0, 0));
        btnAgregar.setText("Agregar");
        btnAgregar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel2.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 90, -1));

        tableDetalle.setBackground(new java.awt.Color(153, 153, 153));
        tableDetalle.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tableDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tableDetalle);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 1198, 327));

        btnModificar.setBackground(new java.awt.Color(204, 204, 204));
        btnModificar.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnModificar.setForeground(new java.awt.Color(0, 0, 0));
        btnModificar.setText("Modificar");
        btnModificar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jPanel2.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 50, 90, -1));

        btnEliminar.setBackground(new java.awt.Color(204, 204, 204));
        btnEliminar.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(0, 0, 0));
        btnEliminar.setText("Eliminar");
        btnEliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel2.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, 100, -1));

        jLabel2.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel2.setText("DETALLES VENTA");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 390, -1, -1));

        btnNuevo.setBackground(new java.awt.Color(204, 204, 204));
        btnNuevo.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 0, 0));
        btnNuevo.setText("Nuevo");
        btnNuevo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel2.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 50, 100, -1));

        btnRegresar.setBackground(new java.awt.Color(204, 204, 204));
        btnRegresar.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(0, 0, 0));
        btnRegresar.setText("Regresar");
        btnRegresar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel2.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 200, -1));

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel3.setText("Id y Vendedor:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        jLabel5.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel5.setText("Total a pagar:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        tableVentas.setBackground(new java.awt.Color(153, 153, 153));
        tableVentas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tableVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableVentasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableVentas);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 668, 261));

        jLabel6.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel6.setText("Fecha de Venta:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\beath\\OneDrive\\Documents\\NetBeansProjects\\pryctoFinalTicketMaster\\src\\main\\java\\util\\windowsXPfondo.jpg")); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1210, 760));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tableVentasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableVentasMouseClicked
        listarDetalleVentas(Integer.parseInt(tableVentas.getValueAt(tableVentas.getSelectedRow(), 0).toString()));
        int selectedRow = tableVentas.getSelectedRow();
        if (selectedRow != -1)
        {
            Object idVendedor = tableVentas.getValueAt(selectedRow, 1);
            Object nombreVendedor = tableVentas.getValueAt(selectedRow, 2);

            String comboBoxValue = idVendedor + " " + nombreVendedor;

            for (int i = 0; i < cboIdYNombreVendedor.getItemCount(); i++)
            {
                if (cboIdYNombreVendedor.getItemAt(i).equals(comboBoxValue))
                {
                    cboIdYNombreVendedor.setSelectedIndex(i);
                    break;
                }
            }
        }
        txtIdVenta.setText(tableVentas.getValueAt(tableVentas.getSelectedRow(), 0).toString());
        txtTotalAPagar.setText(tableVentas.getValueAt(tableVentas.getSelectedRow(), 3).toString());
        txtFechaDeVenta.setText(tableVentas.getValueAt(tableVentas.getSelectedRow(), 4).toString());

    }//GEN-LAST:event_tableVentasMouseClicked

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        dispose();
        FrmAdministrador admin = new FrmAdministrador(nombreUsuario);
        admin.setVisible(true);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed

        //Obtener el último id
        int ultimoId = ventasController.getUltimoIdVentaController();

        //aumentar 1 al ultimo id para el nuevo id
        int nuevoId = ultimoId + 1;

        //Establecer el nuevo ID en el campo de texto
        txtIdVenta.setText(String.valueOf(nuevoId));
        txtTotalAPagar.setText("");
        txtFechaDeVenta.setText("");

        //deseleccionar cualquier fila que esté seleccionada en la tabla
        tableVentas.clearSelection();

    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int msg = JOptionPane.showConfirmDialog(btnEliminar,"Deseas Eliminar el Venta!!!","Eliminar",JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_OPTION)
        {
            Ventas venta = new Ventas();
            venta.setIdVenta(Integer.parseInt(this.txtIdVenta.getText()));
            ventasController.removerVentaController(venta);
            listarListaDeVentas();//Actualizar BD

            DetalleVentas detalle = new DetalleVentas();
            detalle.setIdVenta(Integer.parseInt(this.txtIdVenta.getText()));
            detalleVenController.removerDetalleVentaController(detalle);
            listarDetalleVentas(msg);
            JOptionPane.showMessageDialog(this,"Venta Eliminado Satisfactoriamente");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        /*
        int msg = JOptionPane.showConfirmDialog(btnModificar, "¿DESEAS MODIFICAR EL TIPO?", "MODIFICAR", JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_NO_OPTION) {
            // Obtener la fila seleccionada en la tabla
            int filaSeleccionada = tableVentas.getSelectedRow();

            // Verificar si se seleccionó una fila
            if (filaSeleccionada != -1) {
                // Obtener el idConcepto de la fila seleccionada
                int idVenta = (int) tableVentas.getValueAt(filaSeleccionada, 0);

                Ventas venta = new Ventas();

                //Obtener el elemento seleccionado del ComboBox
                String selectedValue = cboIdYNombreVendedor.getSelectedItem().toString();
                //Dividir el valor seleccionado en ID y nombre del vendedor
                String[] parts = selectedValue.split(" ");

                venta.setIdVenta(idVenta);
                venta.setIdVendedores(Integer.parseInt(parts[0]));
                venta.setNombreVendedor(parts[1]);
                venta.setTotalAPagar(Double.parseDouble(txtTotalAPagar.getText()));
                venta.setFechaDeVenta(Date.valueOf(txtFechaDeVenta.getText()));

                // Llamar al método updateConceptoController con el objeto Conceptos configurado
                ventasController.updateVentaController(venta);
                // Actualizar la lista de conceptos en la tabla
                listarListaDeVentas();

                //////////

                try
                {
                    for (int fila = 0; fila < tableDetalle.getModel().getRowCount(); fila++) {
                        DetalleVentas detalle = new DetalleVentas();

                        detalle.setIdVenta(idVenta);
                        detalle.setIdFuncion((int)tableDetalle.getValueAt(fila,1));
                        detalle.setNombreFuncion((String)tableDetalle.getValueAt(fila,2));
                        detalle.setIdConcepto((int)tableDetalle.getValueAt(fila,3));
                        detalle.setConceptoNombre((String)tableDetalle.getValueAt(fila,4));
                        detalle.setPrecio((double)tableDetalle.getValueAt(fila,5));
                        detalle.setIdVendedores(Integer.parseInt(parts[0]));
                        detalle.setNombreVendedores(parts[1]);
                        detalle.setCantidad((int)tableDetalle.getValueAt(fila, 8));
                        detalle.setTotalAPagar(Double.parseDouble(txtTotalAPagar.getText()));
                        detalle.setNombreCliente((String)tableDetalle.getValueAt(fila, 10));
                        detalle.setDniCliente((String)tableDetalle.getValueAt(fila, 11));
                        detalle.setFechaDeVenta(Date.valueOf(txtFechaDeVenta.getText()));

                        detalleVenController.updateFuncionController(detalle);
                    }
                }catch(Exception e)
                {
                    e.getMessage();
                    System.out.println("FALLOO");
                }

                listarDetalleVentas(msg);

                JOptionPane.showMessageDialog(this, "CONCEPTO MODIFICADO SATISFACTORIAMENTE");
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una fila antes de modificar", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        */

    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        int msg = JOptionPane.showConfirmDialog(btnAgregar,"Deseas Agregar este Venta?","Grabar",JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_OPTION)
        {
            //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
            Ventas venta = new Ventas();

            // Obtener el elemento seleccionado del ComboBox
            String selectedValue = cboIdYNombreVendedor.getSelectedItem().toString();

            // Dividir el valor seleccionado en ID y nombre del vendedor
            String[] parts = selectedValue.split(" ");

            venta.setIdVendedores(Integer.parseInt(parts[0]));
            venta.setNombreVendedor(parts[1]);
            venta.setTotalAPagar(Double.parseDouble(this.txtTotalAPagar.getText()));
            venta.setFechaDeVenta(Date.valueOf(this.txtFechaDeVenta.getText()));
            ventasController.addVentaController(venta);
            listarListaDeVentas();//Actualizar la BD
            JOptionPane.showMessageDialog(this,"Registro Grabado Satisfactoriamente");
        }
        txtIdVenta.setText("");
        txtTotalAPagar.setText("");
        txtFechaDeVenta.setText("");
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void cboIdYNombreVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboIdYNombreVendedorActionPerformed

    }//GEN-LAST:event_cboIdYNombreVendedorActionPerformed

    private void cboIdYNombreVendedorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboIdYNombreVendedorItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cboIdYNombreVendedorItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmVentas("").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JComboBox<String> cboIdYNombreVendedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tableDetalle;
    private javax.swing.JTable tableVentas;
    private javax.swing.JTextField txtFechaDeVenta;
    private javax.swing.JTextField txtIdVenta;
    private javax.swing.JTextField txtTotalAPagar;
    // End of variables declaration//GEN-END:variables
}
