/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.DetalleVentasController;
import controller.VentasController;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import model.DetalleVentas;
import model.Ventas;


/**
 *
 * @author josea
 */
public class FrmFactura extends javax.swing.JFrame {
    
    DefaultTableModel dtmDetalle = new DefaultTableModel();
    DefaultTableModel dtmVendedor = new DefaultTableModel();
    
    
    DetalleVentasController detalleController = new DetalleVentasController();
    VentasController ventaController = new VentasController();
    
    private int idVenta;
    /**
     * Creates new form FrmFactura
     */
    public FrmFactura(int idVenta) {
        initComponents();
        this.idVenta = idVenta;
        
        
        
        llenarColumnasDetalles();
        llenarVendedor();
        listarListaEventos(idVenta);
        listarVendedor(idVenta);
        IngresarDatos(idVenta);
        
 
        
    }
    
    private void imprimirFormulario() {
        // Crear un objeto PrinterJob
        PrinterJob printerJob = PrinterJob.getPrinterJob();

        // Configurar el formulario como el componente a imprimir
        Component formulario = this.getContentPane();

        // Establecer el objeto Printable utilizando el método printAll
        Printable printable = (g, pf, pageIndex) -> {
            if (pageIndex > 0) {
                return Printable.NO_SUCH_PAGE;
            }
            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());
            formulario.printAll(g);
            return Printable.PAGE_EXISTS;
        };

        // Asignar el objeto Printable al PrinterJob
        printerJob.setPrintable(printable);

        // Mostrar el cuadro de diálogo de impresión
        if (printerJob.printDialog()) {
            try {
                // Iniciar la impresión
                printerJob.print();
            } catch (PrinterException e) {
                e.printStackTrace();
                // Manejar la excepción en caso de error durante la impresión
            }
        }
    }
    
    public void IngresarDatos(int idVenta)
    {
        DetalleVentas obj = new DetalleVentas();
        obj.setIdVenta(idVenta);
        List<DetalleVentas> lst = detalleController.getDetalleVentasPorIdController(obj);
        
        if (!lst.isEmpty()) {
        // Obtener el primer elemento de la lista (o ajusta según tus necesidades)
        DetalleVentas detalleVenta = lst.get(0);

        lblCliente.setText(detalleVenta.getNombreCliente());      
        lblDniCliente.setText(detalleVenta.getDniCliente());
        lblDireccion.setText("Avenida de los Eventos | 123 Ciudad: Ciudad Espectáculo");
        lblTipoMoneda.setText("SOLES");
        
        
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String fechaFormateada = fechaActual.format(formatter);
        //Asignar la fecha formateada a txtFecha
        lblfecha.setText(fechaFormateada);
        //lblfecha.setText(detalleVenta.getFechaDeVenta());
        } 
    }
    
    public void CalculoTotal()
    {
        double sumaSubtotales = 0.0;
        int columnaSubtotal = 4; // Índice de la última columna (considerando que las columnas se indexan desde 0)
        for (int fila = 0; fila < dtmDetalle.getRowCount(); fila++) {
            double subtotal = (double) dtmDetalle.getValueAt(fila, columnaSubtotal);
            sumaSubtotales += subtotal;
        }

        // Mostrar la suma en el TextField TOTAL
        txtImporteTotal.setText(String.valueOf(sumaSubtotales));
    }
    
    private void llenarColumnasDetalles()
    {
        
        //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
        dtmDetalle.addColumn("CODIGO");
        dtmDetalle.addColumn("CANTIDAD");
        dtmDetalle.addColumn("DESCRIPCION");
        dtmDetalle.addColumn("PRECIO_UNITARIO");
        dtmDetalle.addColumn("IMPORTE");
        
        this.tableDetalleFactura.setModel(dtmDetalle);
    }
    
    private void llenarVendedor()
    {
        
        //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
        dtmVendedor.addColumn("CODIGO");
        dtmVendedor.addColumn("VENDEDOR");
        dtmVendedor.addColumn("FECHA");
        dtmVendedor.addColumn("TELEFONO");
        
        this.tableVendedor.setModel(dtmVendedor);
    }
    
    public void listarListaEventos(int idVenta)
    {
        //idConcepto, concepto_nombre, idTipo
        DetalleVentas obj = new DetalleVentas();
        obj.setIdVenta(idVenta);
        List<DetalleVentas> lst = detalleController.getDetalleVentasPorIdController(obj);
        dtmDetalle.setNumRows(0);
        
        // Agregar las filas actualizadas al modelo de la tabla
        for (DetalleVentas x : lst) {
            //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
            Object[] vector = new Object[5];
            vector[0] = x.getIdFuncion();
            vector[1] = x.getCantidad();
            vector[2] = x.getNombreFuncion();
            vector[3] = x.getPrecio();
            vector[4] = x.getTotalAPagar();         

            dtmDetalle.addRow(vector);
        }

        // Establecer el modelo actualizado en la tabla
       tableDetalleFactura.setModel(dtmDetalle);
       CalculoTotal();
    }
    
    public void listarVendedor(int idVenta)
    {
        Ventas obj = new Ventas();
        obj.setIdVenta(idVenta);
        List<Ventas> lst = ventaController.getVentaPorIdController(obj);
        dtmVendedor.setNumRows(0);
        String vend = "(01) 456-7890";
        
        // Agregar las filas actualizadas al modelo de la tabla
        for (Ventas x : lst) {
            //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
            Object[] vector = new Object[4];
            vector[0] = x.getIdVendedores();
            vector[1] = x.getNombreVendedor();
            vector[2] = x.getFechaDeVenta();
            vector[3] = vend;    

            dtmVendedor.addRow(vector);
        }
        tableVendedor.setModel(dtmVendedor);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lblDniCliente = new javax.swing.JLabel();
        lblCliente = new javax.swing.JLabel();
        lblDireccion = new javax.swing.JLabel();
        lblfecha = new javax.swing.JLabel();
        lblTipoMoneda = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableDetalleFactura = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableVendedor = new javax.swing.JTable();
        btnImprimirBoleta = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        txtImporteTotal = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("R.U.C    ");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("202425693");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("BOLETA DE VENTA");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("BF-24256461");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(0, 21, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addGap(15, 15, 15))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("Boletería Ticketmaster");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel4.setText("Boletos para Todo. ¡Crea Momentos Inolvidables!\"");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setToolTipText("");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("SEÑOR(A)       :");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("RUC / DNI      :");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("FECHA DE EMISION    :");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("TIPO DE MONEDA       :");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("DIRECCION    :");

        lblDniCliente.setText("jLabel13");

        lblCliente.setText("jLabel14");

        lblDireccion.setText("jLabel15");

        lblfecha.setText("jLabel16");

        lblTipoMoneda.setText("jLabel17");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblCliente)
                                    .addComponent(lblDniCliente))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel7))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblfecha, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblTipoMoneda, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(50, 50, 50))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(lblDireccion)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addComponent(lblfecha))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel10)
                            .addComponent(lblDniCliente)
                            .addComponent(lblTipoMoneda)))
                    .addComponent(lblCliente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(lblDireccion))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        tableDetalleFactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableDetalleFactura);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("IMPORTE_TOTAL");

        tableVendedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tableVendedor);

        btnImprimirBoleta.setText("IMPRIMIR");
        btnImprimirBoleta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirBoletaActionPerformed(evt);
            }
        });

        jLabel18.setText("Dirección: Avenida de los Eventos | 123 Ciudad: Ciudad Espectáculo");

        jLabel19.setText("Telefono: 01 2538359 ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnImprimirBoleta, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(109, 109, 109)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(txtImporteTotal))
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19)
                            .addComponent(jLabel18))
                        .addGap(34, 34, 34)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel19)
                        .addGap(12, 12, 12)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(8, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(204, 204, 204)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtImporteTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnImprimirBoleta, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel11)))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnImprimirBoletaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirBoletaActionPerformed
        imprimirFormulario();
    }//GEN-LAST:event_btnImprimirBoletaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmFactura(1).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnImprimirBoleta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblDniCliente;
    private javax.swing.JLabel lblTipoMoneda;
    private javax.swing.JLabel lblfecha;
    private javax.swing.JTable tableDetalleFactura;
    private javax.swing.JTable tableVendedor;
    private javax.swing.JTextField txtImporteTotal;
    // End of variables declaration//GEN-END:variables
}
