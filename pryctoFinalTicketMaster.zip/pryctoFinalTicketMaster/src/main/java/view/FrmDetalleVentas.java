/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.ConceptosController;
import controller.DetalleVentasController;
import controller.FuncionesController;
import controller.VendedoresController;
import controller.VentasController;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Conceptos;
import model.DetalleVentas;
import model.Funciones;
import model.Vendedores;

/**
 *
 * @author MATT
 */
public class FrmDetalleVentas extends javax.swing.JFrame {

    
    DefaultTableModel dtmDetalle = new DefaultTableModel();
    DetalleVentasController detalleController = new DetalleVentasController();
    VendedoresController vendedorController = new VendedoresController();
    FuncionesController funcionesController = new FuncionesController();
    ConceptosController conceptosController = new ConceptosController();
    VentasController ventasController = new VentasController();
    
    //necesitamos esto para regresar al FrmAdministrador
    private String nombreUsuario;
    
    /**
     * Creates new form FrmDetalleVentas
     */
    public FrmDetalleVentas(String nombreUsuario) {
        initComponents();
        this.nombreUsuario = nombreUsuario;
        
        
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Formulario de Detalle de Ventas");
        
        llenarColumnaDetalleVenta();
        listarTodoDetalleVentas();
        inicializarFechaActual();
        llenaComboIDYNombreConceptos();
        llenaComboIDYNombreFunciones();
        llenaComboIDYNombreVendedores();
        
        
    }
    
    public void inicializarFechaActual() {
        //Esto es para obtener la fecha actual y asignarla a txtFecha
        LocalDate fechaActual = LocalDate.now();
        //Formatear la fecha en el formato deseado (year-month-day)
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String fechaFormateada = fechaActual.format(formatter);
        //Asignar la fecha formateada a txtFecha
        txtFechaVenta.setText(fechaFormateada);
    }
    
    private void llenarColumnaDetalleVenta()
    {
        
        dtmDetalle.addColumn("ID DE VENTA");
        dtmDetalle.addColumn("ID DE FUNCION");
        dtmDetalle.addColumn("NOMBRE DE FUNCION");
        dtmDetalle.addColumn("ID DE CONCEPTO");
        dtmDetalle.addColumn("NOMBRE DE CONCEPTO");
        dtmDetalle.addColumn("PRECIO UNITARIO");
        dtmDetalle.addColumn("ID DE ENCARGADO");
        dtmDetalle.addColumn("NOMBRE DE ENCARGADO");
        dtmDetalle.addColumn("CANTIDAD");
        dtmDetalle.addColumn("TOTAL A PAGAR");
        dtmDetalle.addColumn("NOMBRE DE CLIENTE");
        dtmDetalle.addColumn("DNI DE CLIENTE");
        dtmDetalle.addColumn("FECHA DE VENTA");
        
    }
    
    
    
    public void listarTodoDetalleVentas()
    {
        List<DetalleVentas> lst = detalleController.getAllDetalleVentasController();
        for(DetalleVentas x:lst)
        {
            
            Object[] vector = new Object[13];
            vector[0] = x.getIdVenta();
            vector[1] = x.getIdFuncion();
            vector[2] = x.getNombreFuncion();
            vector[3] = x.getIdConcepto();
            vector[4] = x.getConceptoNombre();
            vector[5] = x.getPrecio();
            vector[6] = x.getIdVendedores();
            vector[7] = x.getNombreVendedores();
            vector[8] = x.getCantidad();
            vector[9] = x.getTotalAPagar();
            vector[10] = x.getNombreCliente();
            vector[11] = x.getDniCliente();
            vector[12] = x.getFechaDeVenta();
            
            
            
            dtmDetalle.addRow(vector);
        }
        tableDetalleVentas.setModel(dtmDetalle);
    }
    
    public void llenaComboIDYNombreVendedores()
    {
        List<Vendedores> lst = vendedorController.getAllVendedoresController();
        for(Vendedores x: lst)
        {
            this.cboVendedor.addItem(x.getIdVendedores()+ " " + x.getNombreVendedores());
        }
    }
    
    public void llenaComboIDYNombreFunciones()
    {
        List<Funciones> lst = funcionesController.getAllFuncionesController();
        for(Funciones x: lst)
        {
            this.cboFuncion.addItem(x.getIdFuncion()+ " " + x.getNombreFuncion());
        }
    }
    
    public void llenaComboIDYNombreConceptos()
    {
        List<Conceptos> lst = conceptosController.getAllConceptosController();
        for(Conceptos x: lst)
        {
            this.cboConcepto.addItem(x.getIdConcepto()+ " " + x.getConcepto_nombre());
        }
    }
    
    public void setearCombosSeparandoFunciones()
    {
        int selectedRow = tableDetalleVentas.getSelectedRow();
        /*No se asusten esto es para separar los ID de las definiciones del cbo*/
        String nombreFuncion = cboFuncion.getSelectedItem().toString();
        String[] partesFuncion = nombreFuncion.split(" ", 2);
        String nombreFuncionFinal = partesFuncion[1];
        
        if (selectedRow != -1)
        {
            //ASIGNANDO VALORES DE LA TABLA A VARIABLES
            Object idFuncion = tableDetalleVentas.getValueAt(selectedRow, 1);
            Object nombreFunciones = tableDetalleVentas.getValueAt(selectedRow, 2);
            
            
            String comboBoxValue1 = idFuncion + " " + nombreFunciones;
            
            for (int i = 0; i < cboFuncion.getItemCount(); i++)
            {
                if (cboFuncion.getItemAt(i).equals(comboBoxValue1)) 
                {
                    cboFuncion.setSelectedIndex(i);
                    break;
                }
            }
        }
        
    }
    
    public void setearCombosSeparandoVendedores()
    {
        int selectedRow = tableDetalleVentas.getSelectedRow();
        /*No se asusten esto es para separar los ID de las definiciones del cbo*/
        String nombreVendedor = cboVendedor.getSelectedItem().toString();
        String[] partesVendedor = nombreVendedor.split(" ", 2);
        String nombreVendedorFinal = partesVendedor[1];
        
        if (selectedRow != -1)
        {
            //ASIGNANDO VALORES DE LA TABLA A VARIABLES
            Object idVendedor = tableDetalleVentas.getValueAt(selectedRow, 6);
            Object nombreVendedores = tableDetalleVentas.getValueAt(selectedRow, 7);
            
            
            String comboBoxValue1 = idVendedor + " " + nombreVendedores;
            
            for (int i = 0; i < cboVendedor.getItemCount(); i++)
            {
                if (cboVendedor.getItemAt(i).equals(comboBoxValue1)) 
                {
                    cboVendedor.setSelectedIndex(i);
                    break;
                }
            }
        }
        
    }
    
    public void setearCombosSeparandoConceptos()
    {
        int selectedRow = tableDetalleVentas.getSelectedRow();
        /*No se asusten esto es para separar los ID de las definiciones del cbo*/
        String nombreConcepto = cboConcepto.getSelectedItem().toString();
        String[] partesConcepto = nombreConcepto.split(" ", 2);
        String nombreConceptoFinal = partesConcepto[1];
        
        if (selectedRow != -1)
        {
            //ASIGNANDO VALORES DE LA TABLA A VARIABLES
            Object idConcepto = tableDetalleVentas.getValueAt(selectedRow, 3);
            Object nombreConceptos = tableDetalleVentas.getValueAt(selectedRow, 4);
            
            
            String comboBoxValue1 = idConcepto + " " + nombreConceptos;
            
            for (int i = 0; i < cboConcepto.getItemCount(); i++)
            {
                if (cboConcepto.getItemAt(i).equals(comboBoxValue1)) 
                {
                    cboConcepto.setSelectedIndex(i);
                    break;
                }
            }
        }
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cboConcepto = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        cboFuncion = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        txtIDVenta = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableDetalleVentas = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        txtNombreCliente = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtDNICliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtFechaVenta = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTotalAPagar = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cboVendedor = new javax.swing.JComboBox<>();
        btnRegresar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cboConcepto.setBackground(new java.awt.Color(204, 204, 204));
        cboConcepto.setForeground(new java.awt.Color(0, 0, 0));
        cboConcepto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(cboConcepto, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 63, 220, -1));

        jLabel7.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Total:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 178, -1, -1));

        cboFuncion.setBackground(new java.awt.Color(204, 204, 204));
        cboFuncion.setForeground(new java.awt.Color(0, 0, 0));
        cboFuncion.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(cboFuncion, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 35, 220, -1));

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Nombre de Cliente:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 206, -1, -1));

        txtIDVenta.setEditable(false);
        txtIDVenta.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtIDVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 6, 220, -1));

        jLabel9.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("DNI de Cliente:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 234, -1, -1));

        txtPrecio.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 91, 220, -1));

        tableDetalleVentas.setBackground(new java.awt.Color(204, 204, 204));
        tableDetalleVentas.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tableDetalleVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableDetalleVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableDetalleVentasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableDetalleVentas);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 292, 1329, 258));

        jLabel10.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Fecha de Venta:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 262, -1, -1));

        btnNuevo.setBackground(new java.awt.Color(204, 204, 204));
        btnNuevo.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 0, 0));
        btnNuevo.setText("Nuevo");
        btnNuevo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel1.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(379, 6, 110, -1));

        txtNombreCliente.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 203, 220, -1));

        jLabel1.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Id de Venta:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 9, -1, -1));

        txtDNICliente.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtDNICliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 231, 220, -1));

        jLabel2.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Función:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 38, -1, -1));

        txtFechaVenta.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtFechaVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 259, 220, -1));

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Concepto:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 66, -1, -1));

        txtTotalAPagar.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtTotalAPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 175, 220, -1));

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Precio Unitario:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 94, -1, -1));

        txtCantidad.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 147, 220, -1));

        jLabel5.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Encargado:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 122, -1, -1));

        cboVendedor.setBackground(new java.awt.Color(204, 204, 204));
        cboVendedor.setForeground(new java.awt.Color(0, 0, 0));
        cboVendedor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(cboVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 119, 220, -1));

        btnRegresar.setBackground(new java.awt.Color(204, 204, 204));
        btnRegresar.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(0, 0, 0));
        btnRegresar.setText("Regresar");
        btnRegresar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 40, 110, -1));

        jLabel6.setFont(new java.awt.Font("Microsoft YaHei", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Cantidad:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 150, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\beath\\OneDrive\\Documents\\NetBeansProjects\\pryctoFinalTicketMaster\\src\\main\\java\\util\\windowsXPfondo.jpg")); // NOI18N
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(-7, -5, 1350, 570));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        
        //Obtener el último id
        int ultimoId = ventasController.getUltimoIdVentaController();

        //aumentar 1 al ultimo id para el nuevo id
        int nuevoId = ultimoId + 1;

        //Establecer el nuevo ID en el campo de texto
        txtIDVenta.setText(String.valueOf(nuevoId));
        txtCantidad.setText("");
        txtNombreCliente.setText("");
        txtDNICliente.setText("");
        //txtTotal.setText("");

        //deseleccionar cualquier fila que esté seleccionada en la tabla
        //tableDetalle.clearSelection();
        inicializarFechaActual();
    
        
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void tableDetalleVentasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableDetalleVentasMouseClicked
        txtIDVenta.setText(tableDetalleVentas.getValueAt(tableDetalleVentas.getSelectedRow(), 0).toString());
        txtPrecio.setText(tableDetalleVentas.getValueAt(tableDetalleVentas.getSelectedRow(), 5).toString());
        txtTotalAPagar.setText(tableDetalleVentas.getValueAt(tableDetalleVentas.getSelectedRow(), 9).toString());
        txtCantidad.setText(tableDetalleVentas.getValueAt(tableDetalleVentas.getSelectedRow(), 8).toString());
        txtNombreCliente.setText(tableDetalleVentas.getValueAt(tableDetalleVentas.getSelectedRow(), 10).toString());
        txtDNICliente.setText(tableDetalleVentas.getValueAt(tableDetalleVentas.getSelectedRow(), 11).toString());
        setearCombosSeparandoFunciones();
        setearCombosSeparandoVendedores();
        setearCombosSeparandoConceptos();
    }//GEN-LAST:event_tableDetalleVentasMouseClicked

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        dispose();
        FrmAdministrador admin = new FrmAdministrador(nombreUsuario);
        admin.setVisible(true);
    }//GEN-LAST:event_btnRegresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmDetalleVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmDetalleVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmDetalleVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmDetalleVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmDetalleVentas("Nombre de Usuario").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JComboBox<String> cboConcepto;
    private javax.swing.JComboBox<String> cboFuncion;
    private javax.swing.JComboBox<String> cboVendedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tableDetalleVentas;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtDNICliente;
    private javax.swing.JTextField txtFechaVenta;
    private javax.swing.JTextField txtIDVenta;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtTotalAPagar;
    // End of variables declaration//GEN-END:variables
}
