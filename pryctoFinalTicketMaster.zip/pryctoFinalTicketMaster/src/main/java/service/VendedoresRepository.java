/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Vendedores;
import model.Vendedores;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class VendedoresRepository implements IVendedores {

    @Override
    public List<Vendedores> getAllVendedores() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Vendedores> lstVendedores = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceVendedores = Conexion.ObtenerConexion().prepareCall("{CALL USPListarVendedores}");
            ResultSet rsVendedores = ceVendedores.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsVendedores.next())    
            {
                //idVendedores,idConcepto,idTipo,conc_nombre,conc_fecha,conc_lugar,conc_disponibilidad
                Vendedores objVendedores = new Vendedores();
                
                //idVendedores, usuario_nick, usuario_password, usuario_nombre, usuario_paterno, usuario_materno, usuario_dni, usuario_email
                
                objVendedores.setIdVendedores(Integer.parseInt(rsVendedores.getString("idVendedores")));
                objVendedores.setNombreVendedores(rsVendedores.getString("nombreVendedores"));
                
                
                lstVendedores.add(objVendedores);
            }
            return lstVendedores;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addVendedores(Vendedores obj) {
        try
        {
            //idVendedores, usuario_nick, usuario_password, usuario_nombre, usuario_paterno, usuario_materno, usuario_dni, usuario_email
            PreparedStatement stVendedores = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarVendedores(?)}");
            stVendedores.setString(1,obj.getNombreVendedores());
            
            stVendedores.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void removeVendedores(Vendedores obj) {
        try
        {
            PreparedStatement stVendedores = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarVendedores(?)}"); 
            stVendedores.setInt(1,obj.getIdVendedores());
            
            stVendedores.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void updateVendedores(Vendedores obj) {
        try
        {
            //idVendedores,idConcepto,idTipo,conc_nombre,conc_fecha,conc_lugar,conc_disponibilidad
            PreparedStatement stVendedores = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarVendedores(?,?,?)}"); 
            stVendedores.setInt(1,obj.getIdVendedores());
            stVendedores.setString(2,obj.getNombreVendedores());
            
            stVendedores.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
}
