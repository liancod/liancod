/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Administradores;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class AdministradoresRepository implements IAdministradores {

    @Override
    public List<Administradores> getAllAdministradores() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Administradores> lstAdministradores = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceAdministradores = Conexion.ObtenerConexion().prepareCall("{CALL USPListarAdministradores}");
            ResultSet rsAdministradores = ceAdministradores.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsAdministradores.next())    
            {
                //idAdministradores,idConcepto,idTipo,conc_nombre,conc_fecha,conc_lugar,conc_disponibilidad
                Administradores objAdministradores = new Administradores();
                
                //idAdministradores, usuario_nick, usuario_password, usuario_nombre, usuario_paterno, usuario_materno, usuario_dni, usuario_email
                
                objAdministradores.setIdAdmin(Integer.parseInt(rsAdministradores.getString("idAdmin")));
                objAdministradores.setAdmin_nick(rsAdministradores.getString("admin_nick"));
                objAdministradores.setAdmin_password(rsAdministradores.getString("admin_password"));
                
                
                lstAdministradores.add(objAdministradores);
            }
            return lstAdministradores;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addAdministradores(Administradores obj) {
        try
        {
            //idAdministradores, usuario_nick, usuario_password, usuario_nombre, usuario_paterno, usuario_materno, usuario_dni, usuario_email
            PreparedStatement stAdministradores = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarAdministradores(?,?)}"); //aunque no seteamos el id, los parametros lo toman porque así esta el procedure
            stAdministradores.setString(1,obj.getAdmin_nick());
            stAdministradores.setString(2, obj.getAdmin_password());
            
            
            stAdministradores.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void removeAdministradores(Administradores obj) {
        try
        {
            PreparedStatement stAdministradores = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarAdministradores(?)}"); 
            stAdministradores.setInt(1,obj.getIdAdmin());
            
            stAdministradores.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void updateAdministradores(Administradores obj) {
        try
        {
            //idAdministradores,idConcepto,idTipo,conc_nombre,conc_fecha,conc_lugar,conc_disponibilidad
            PreparedStatement stAdministradores = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarAdministradores(?,?,?)}"); 
            stAdministradores.setInt(1,obj.getIdAdmin());
            stAdministradores.setString(2,obj.getAdmin_nick());
            stAdministradores.setString(3, obj.getAdmin_password());
            
            stAdministradores.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public boolean verificarCredenciales(String usuario, String contrasena) {
        List<Administradores> administrador = getAllAdministradores();
        for (Administradores a : administrador) {
            if (a.getAdmin_nick().trim().equals(usuario) && a.getAdmin_password().trim().equals(contrasena)) {
                return true; // Credenciales válidas
            }
        }
        return false; // No se encontraron credenciales válidas
    }
    
}
