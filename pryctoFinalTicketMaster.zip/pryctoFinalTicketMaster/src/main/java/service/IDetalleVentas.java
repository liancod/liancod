/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.DetalleVentas;
import model.DetalleVentas;

/**
 *
 * @author MATT
 */
public interface IDetalleVentas {
    List<DetalleVentas> getAllDetalleVentas();
    List<DetalleVentas> getDetallesVentasPorId(DetalleVentas obj);
    void addDetalleVenta(DetalleVentas obj);
    void removeDetalleVenta(DetalleVentas obj);
    void updateDetalleVenta(DetalleVentas obj);
}
