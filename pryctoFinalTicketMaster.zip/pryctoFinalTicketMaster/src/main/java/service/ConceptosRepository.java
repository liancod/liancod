/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Conceptos;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class ConceptosRepository implements IConceptos {

    @Override
    public List<Conceptos> getAllConceptos() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Conceptos> lstConceptos = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceConceptos = Conexion.ObtenerConexion().prepareCall("{CALL USPListarConceptos()}");
            ResultSet rsConceptos = ceConceptos.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsConceptos.next())    
            {
                Conceptos objConceptos = new Conceptos();   
                objConceptos.setIdConcepto(Integer.parseInt(rsConceptos.getString("idConcepto")));
                objConceptos.setConcepto_nombre(rsConceptos.getString("concepto_nombre"));
                
                lstConceptos.add(objConceptos);
            }
            return lstConceptos;
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void addConcepto(Conceptos obj) {
       try
        {
            //idConcepto, usuario_nick, usuario_password, usuario_nombre, usuario_paterno, usuario_materno, usuario_dni, usuario_email
            PreparedStatement stConcepto = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarConceptos(?)}");
            stConcepto.setString(1, obj.getConcepto_nombre());
            
            stConcepto.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        } 
    }

    @Override
    public void removeConcepto(Conceptos obj) {
       try {
        System.out.println("ID del concepto a eliminar (Repository): " + obj.getIdConcepto());

        PreparedStatement stConcepto = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarConceptos(?)}"); 
        stConcepto.setInt(1, obj.getIdConcepto());

        stConcepto.executeUpdate(); // GRABAR EN LA BD
       } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateConcepto(Conceptos obj) {
        try
        {
            //idConcepto,idConcepto,idTipo,conc_nombre,conc_fecha,conc_lugar,conc_disponibilidad
            PreparedStatement stConcepto = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarFunciones(?,?)}"); 
            stConcepto.setInt(1,obj.getIdConcepto());
            stConcepto.setString(2, obj.getConcepto_nombre());
            
            stConcepto.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
}
