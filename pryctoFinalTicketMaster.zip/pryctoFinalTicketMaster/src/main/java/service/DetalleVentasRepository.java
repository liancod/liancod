/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.DetalleVentas;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class DetalleVentasRepository implements IDetalleVentas {

    @Override
    public List<DetalleVentas> getAllDetalleVentas() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<DetalleVentas> lstDetalleVentas = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceDetalleVentas = Conexion.ObtenerConexion().prepareCall("{CALL USPListarDetalleVentas()}");
            ResultSet rsDetalleVentas = ceDetalleVentas.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsDetalleVentas.next())    
            {
                //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
                DetalleVentas objDetalleVentas = new DetalleVentas();   
                objDetalleVentas.setIdVenta(Integer.parseInt(rsDetalleVentas.getString("idVenta")));
                objDetalleVentas.setIdFuncion(Integer.parseInt(rsDetalleVentas.getString("idFuncion")));
                objDetalleVentas.setNombreFuncion(rsDetalleVentas.getString("nombreFuncion"));
                objDetalleVentas.setIdConcepto(Integer.parseInt(rsDetalleVentas.getString("idConcepto")));
                objDetalleVentas.setConceptoNombre(rsDetalleVentas.getString("conceptoNombre"));
                objDetalleVentas.setPrecio(Double.parseDouble(rsDetalleVentas.getString("precio")));
                objDetalleVentas.setIdVendedores(Integer.parseInt(rsDetalleVentas.getString("idVendedores")));
                objDetalleVentas.setNombreVendedores(rsDetalleVentas.getString("nombreVendedores"));
                objDetalleVentas.setCantidad(Integer.parseInt(rsDetalleVentas.getString("cantidad")));
                objDetalleVentas.setTotalAPagar(Double.parseDouble(rsDetalleVentas.getString("totalAPagar")));
                objDetalleVentas.setNombreCliente(rsDetalleVentas.getString("nombreCliente"));
                objDetalleVentas.setDniCliente(rsDetalleVentas.getString("dniCliente"));
                objDetalleVentas.setFechaDeVenta(Date.valueOf(rsDetalleVentas.getString("fechaDeVenta")));
                
                lstDetalleVentas.add(objDetalleVentas);
            }
            return lstDetalleVentas;
        }
        catch(Exception e)
        {
            e.getMessage();
            System.out.println("erro conexion");
        }
        return null;
    }

    @Override
    public void addDetalleVenta(DetalleVentas obj) {
        try
        {
            //idVenta,idFuncion,nombreFuncion,idConcepto,conceptoNombre,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,nombreCliente,dniCliente,fechaDeVenta
            PreparedStatement stDetalleVenta = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarDetalleVentas(?,?,?,?,?,?,?,?,?,?,?,?,?)}"); //aqui toma solo los datos menos el id
            stDetalleVenta.setInt(1, obj.getIdVenta());
            stDetalleVenta.setInt(2, obj.getIdFuncion());
            stDetalleVenta.setString(3,obj.getNombreFuncion());
            stDetalleVenta.setInt(4, obj.getIdConcepto());
            stDetalleVenta.setString(5,obj.getConceptoNombre());
            stDetalleVenta.setDouble(6, obj.getPrecio());
            stDetalleVenta.setInt(7, obj.getIdVendedores());
            stDetalleVenta.setString(8,obj.getNombreVendedores());
            stDetalleVenta.setInt(9, obj.getCantidad());
            stDetalleVenta.setDouble(10, obj.getTotalAPagar());
            stDetalleVenta.setString(11,obj.getNombreCliente());
            stDetalleVenta.setString(12,obj.getDniCliente());
            stDetalleVenta.setDate(13, new java.sql.Date(obj.getFechaDeVenta().getTime()));
            
            stDetalleVenta.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("Error al conectar con la base de datos.");
        } 
    }

    @Override
    public void removeDetalleVenta(DetalleVentas obj) {
        try {          
            PreparedStatement stDetalleVenta = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarDetallesVentaPorID(?)}"); 
            stDetalleVenta.setInt(1, obj.getIdVenta());

            stDetalleVenta.executeUpdate(); // GRABAR EN LA BD
        } catch(Exception e) {
            e.printStackTrace();
             System.out.println("Error de nuevo");
        }
    }

    @Override
    public void updateDetalleVenta(DetalleVentas obj) {
        try
        {
            //
            PreparedStatement stDetalleVenta = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarDetalleVenta(?,?,?,?,?,?,?,?,?,?,?,?,?)}"); 
            stDetalleVenta.setInt(1, obj.getIdVenta());
            stDetalleVenta.setInt(2, obj.getIdFuncion());
            stDetalleVenta.setString(3,obj.getNombreFuncion());
            stDetalleVenta.setInt(4, obj.getIdConcepto());
            stDetalleVenta.setString(5,obj.getConceptoNombre());
            stDetalleVenta.setDouble(6, obj.getPrecio());
            stDetalleVenta.setInt(7, obj.getIdVendedores());
            stDetalleVenta.setString(8,obj.getNombreVendedores());
            stDetalleVenta.setInt(9, obj.getCantidad());
            stDetalleVenta.setDouble(10, obj.getTotalAPagar());
            stDetalleVenta.setString(11,obj.getNombreCliente());
            stDetalleVenta.setString(12,obj.getDniCliente());
            stDetalleVenta.setDate(13, new java.sql.Date(obj.getFechaDeVenta().getTime()));
            
            stDetalleVenta.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("Error de nuevo");
        }
    }

    @Override
    public List<DetalleVentas> getDetallesVentasPorId(DetalleVentas obj) {
        try
        {
            /*Crear el arreglo dinamico*/
            List<DetalleVentas> lstDetalleVentas = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceDetalleVentas = Conexion.ObtenerConexion().prepareCall("{CALL USPListarDetalleVentasPorId(?)}");
            ceDetalleVentas.setInt(1, obj.getIdVenta());
            ResultSet rsDetalleVentas = ceDetalleVentas.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsDetalleVentas.next())    
            {
                //idFuncion,nombreFuncion,idConcepto,conceptoNombre,idVenta,precio,idVendedores,nombreVendedores,cantidad,totalAPagar,fechaDeVenta
                DetalleVentas objDetalleVentas = new DetalleVentas();   
                objDetalleVentas.setIdVenta(Integer.parseInt(rsDetalleVentas.getString("idVenta")));
                objDetalleVentas.setIdFuncion(Integer.parseInt(rsDetalleVentas.getString("idFuncion")));
                objDetalleVentas.setNombreFuncion(rsDetalleVentas.getString("nombreFuncion"));
                objDetalleVentas.setIdConcepto(Integer.parseInt(rsDetalleVentas.getString("idConcepto")));
                objDetalleVentas.setConceptoNombre(rsDetalleVentas.getString("conceptoNombre"));
                objDetalleVentas.setPrecio(Double.parseDouble(rsDetalleVentas.getString("precio")));
                objDetalleVentas.setIdVendedores(Integer.parseInt(rsDetalleVentas.getString("idVendedores")));
                objDetalleVentas.setNombreVendedores(rsDetalleVentas.getString("nombreVendedores"));
                objDetalleVentas.setCantidad(Integer.parseInt(rsDetalleVentas.getString("cantidad")));
                objDetalleVentas.setTotalAPagar(Double.parseDouble(rsDetalleVentas.getString("totalAPagar")));
                objDetalleVentas.setNombreCliente(rsDetalleVentas.getString("nombreCliente"));
                objDetalleVentas.setDniCliente(rsDetalleVentas.getString("dniCliente"));
                objDetalleVentas.setFechaDeVenta(Date.valueOf(rsDetalleVentas.getString("fechaDeVenta")));
                
                lstDetalleVentas.add(objDetalleVentas);
            }
            return lstDetalleVentas;
        }
        catch(Exception e)
        {
            e.getMessage();
            System.out.println("error conexion");
        }
        return null;
    }
    
}
