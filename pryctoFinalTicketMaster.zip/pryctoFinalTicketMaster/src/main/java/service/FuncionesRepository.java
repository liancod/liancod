/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Funciones;
import model.Funciones;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class FuncionesRepository implements IFunciones {

    @Override
    public List<Funciones> getAllFunciones() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Funciones> lstFunciones = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceFunciones = Conexion.ObtenerConexion().prepareCall("{CALL USPListarFunciones}");
            ResultSet rsFunciones = ceFunciones.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsFunciones.next())    
            {
                
                Funciones objFunciones = new Funciones();
                
                //idFuncion,idConcepto,conceptoNombre,nombreFuncion,idTipos,tipoNombre,lugarFuncion,fechaFuncion,disponibleFuncion,precio
                objFunciones.setIdFuncion(Integer.parseInt(rsFunciones.getString("idFuncion")));
                objFunciones.setIdConcepto(Integer.parseInt(rsFunciones.getString("idConcepto")));
                objFunciones.setConceptoNombre(rsFunciones.getString("conceptoNombre"));
                objFunciones.setNombreFuncion(rsFunciones.getString("nombreFuncion"));
                objFunciones.setIdTipos(Integer.parseInt(rsFunciones.getString("idTipos")));
                objFunciones.setTipoNombre(rsFunciones.getString("tipoNombre"));
                objFunciones.setLugarFuncion(rsFunciones.getString("lugarFuncion"));
                objFunciones.setFechaFuncion(rsFunciones.getDate("fechaFuncion"));
                objFunciones.setDisponibleFuncion(rsFunciones.getString("disponibleFuncion"));
                objFunciones.setPrecio(Double.parseDouble(rsFunciones.getString("precio")));
                
                
                
                lstFunciones.add(objFunciones);
            }
            return lstFunciones;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addFunciones(Funciones obj) {
        try
        {
            //
            PreparedStatement stFuncion = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarFunciones(?,?,?,?,?,?,?,?,?)}");
            stFuncion.setInt(1, obj.getIdConcepto());
            stFuncion.setString(2, obj.getConceptoNombre());
            stFuncion.setString(3, obj.getNombreFuncion());
            stFuncion.setInt(4, obj.getIdTipos());
            stFuncion.setString(5, obj.getTipoNombre());
            stFuncion.setString(6, obj.getLugarFuncion());
            stFuncion.setDate(7, new java.sql.Date(obj.getFechaFuncion().getTime()));
            stFuncion.setString(8, obj.getDisponibleFuncion());
            stFuncion.setDouble(9, obj.getPrecio());
            
            stFuncion.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("ERROr");
        } 
    }

    @Override
    public void removeFunciones(Funciones obj) {
        try {          
            System.out.println("ID de la funcion a eliminar (Repository): " + obj.getIdFuncion());

            PreparedStatement stFuncion = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarFuncionesPorID(?)}"); 
            stFuncion.setInt(1, obj.getIdFuncion());

            stFuncion.executeUpdate(); // GRABAR EN LA BD
        } catch(Exception e) {
            e.printStackTrace();
             System.out.println("Error de nuevo2");
        }
    }

    @Override
    public void updateFunciones(Funciones obj) {
        try
        {
            //
            PreparedStatement stFuncion = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarFunciones(?,?,?,?,?,?,?,?,?,?)}"); 
            stFuncion.setInt(1, obj.getIdFuncion());
            stFuncion.setInt(2, obj.getIdConcepto());
            stFuncion.setString(3, obj.getConceptoNombre());
            stFuncion.setString(4, obj.getNombreFuncion());
            stFuncion.setInt(5, obj.getIdTipos());
            stFuncion.setString(6, obj.getTipoNombre());
            stFuncion.setString(7, obj.getLugarFuncion());
            stFuncion.setDate(8, new java.sql.Date(obj.getFechaFuncion().getTime()));
            stFuncion.setString(9, obj.getDisponibleFuncion());
            stFuncion.setDouble(10, obj.getPrecio());
            
            stFuncion.executeUpdate(); //GRABAR EN LA BD
            
            int affectedRows = stFuncion.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Actualización exitosa");
            } else {
                System.out.println("No se realizaron cambios");
            }
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("Error de nuevo");
        }
    }

    @Override
    public List<Funciones> getFuncionesPorId(Funciones obj) {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Funciones> lstFunciones = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceFunciones = Conexion.ObtenerConexion().prepareCall("{CALL USPListarFuncionesPorId(?)}");
            ceFunciones.setInt(1, obj.getIdFuncion());
            ResultSet rsFunciones = ceFunciones.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsFunciones.next())    
            {
                
                Funciones objFunciones = new Funciones();
                
                //idFuncion,idConcepto,conceptoNombre,nombreFuncion,idTipos,tipoNombre,lugarFuncion,fechaFuncion,disponibleFuncion,precio
                objFunciones.setIdFuncion(Integer.parseInt(rsFunciones.getString("idFuncion")));
                objFunciones.setIdConcepto(Integer.parseInt(rsFunciones.getString("idConcepto")));
                objFunciones.setConceptoNombre(rsFunciones.getString("conceptoNombre"));
                objFunciones.setNombreFuncion(rsFunciones.getString("nombreFuncion"));
                objFunciones.setIdTipos(Integer.parseInt(rsFunciones.getString("idTipos")));
                objFunciones.setTipoNombre(rsFunciones.getString("tipoNombre"));
                objFunciones.setLugarFuncion(rsFunciones.getString("lugarFuncion"));
                objFunciones.setFechaFuncion(rsFunciones.getDate("fechaFuncion"));
                objFunciones.setDisponibleFuncion(rsFunciones.getString("disponibleFuncion"));
                objFunciones.setPrecio(Double.parseDouble(rsFunciones.getString("precio")));
                
                
                
                lstFunciones.add(objFunciones);
            }
            return lstFunciones;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
}
