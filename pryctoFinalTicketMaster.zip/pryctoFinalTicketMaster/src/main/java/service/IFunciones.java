/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Funciones;

/**
 *
 * @author MATT
 */
public interface IFunciones {
    List<Funciones> getAllFunciones();
    List<Funciones> getFuncionesPorId(Funciones obj);
    void addFunciones(Funciones obj);
    void removeFunciones(Funciones obj);
    void updateFunciones(Funciones obj);
}
