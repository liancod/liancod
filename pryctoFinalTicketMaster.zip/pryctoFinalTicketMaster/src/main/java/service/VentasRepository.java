/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Ventas;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class VentasRepository implements IVenta {

    @Override
    public List<Ventas> getAllVentas() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Ventas> lstVentas = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceVentas = Conexion.ObtenerConexion().prepareCall("{CALL USPListarVentas()}");
            ResultSet rsVentas = ceVentas.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsVentas.next())    
            {
                //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
                Ventas objVentas = new Ventas();   
                objVentas.setIdVenta(Integer.parseInt(rsVentas.getString("idVenta")));
                objVentas.setIdVendedores(Integer.parseInt(rsVentas.getString("idVendedores")));
                objVentas.setNombreVendedor(rsVentas.getString("nombreVendedor"));
                objVentas.setTotalAPagar(Double.parseDouble(rsVentas.getString("totalAPagar")));
                objVentas.setFechaDeVenta(rsVentas.getDate("fechaDeVenta"));
                
                lstVentas.add(objVentas);
            }
            return lstVentas;
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void addVenta(Ventas obj) {
        try
        {
            //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
            PreparedStatement stVenta = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarVentas(?,?,?,?)}"); //aqui toma solo los datos menos el id
            stVenta.setInt(1, obj.getIdVendedores());
            stVenta.setString(2,obj.getNombreVendedor());
            stVenta.setDouble(3, obj.getTotalAPagar());
            stVenta.setDate(4, new java.sql.Date(obj.getFechaDeVenta().getTime()));
            
            
            stVenta.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        } 
    }

    @Override
    public void removeVenta(Ventas obj) {
        try {

        PreparedStatement stVenta = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarVentaPorID(?)}");  //aqui toma solo el id
        stVenta.setInt(1, obj.getIdVenta());

        stVenta.executeUpdate(); // GRABAR EN LA BD
        } catch(Exception e) {
            e.printStackTrace();
            System.out.println("OCURRIO UN PROBLEMA");
        }
    }

    @Override
    public void updateVenta(Ventas obj) {
        try
        {
            //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
            PreparedStatement stVenta = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarVentas(?,?,?,?,?)}"); //aqui toma el id y los demas datos
            stVenta.setInt(1,obj.getIdVenta());
            stVenta.setInt(2, obj.getIdVendedores());
            stVenta.setString(3, obj.getNombreVendedor());
            stVenta.setDouble(4, obj.getTotalAPagar());
            stVenta.setDate(5, new java.sql.Date(obj.getFechaDeVenta().getTime()));
            
            stVenta.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public List<Ventas> getVentaPorId(Ventas obj) {
       try
        {
            /*Crear el arreglo dinamico*/
            List<Ventas> lstVentas = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceVentas = Conexion.ObtenerConexion().prepareCall("{CALL USPListarVentaPorID(?)}");
            ceVentas.setInt(1, obj.getIdVenta());
            ResultSet rsVentas = ceVentas.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsVentas.next())    
            {
                //idVenta, idVendedores, nombreVendedor, totalAPagar, fechaDeVenta
                Ventas objVentas = new Ventas();   
                objVentas.setIdVenta(Integer.parseInt(rsVentas.getString("idVenta")));
                objVentas.setIdVendedores(Integer.parseInt(rsVentas.getString("idVendedores")));
                objVentas.setNombreVendedor(rsVentas.getString("nombreVendedor"));
                objVentas.setTotalAPagar(Double.parseDouble(rsVentas.getString("totalAPagar")));
                objVentas.setFechaDeVenta(rsVentas.getDate("fechaDeVenta"));
                
                lstVentas.add(objVentas);
            }
            return lstVentas;
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }
    
}
