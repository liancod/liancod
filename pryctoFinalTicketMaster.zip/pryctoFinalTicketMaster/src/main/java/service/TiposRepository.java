/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Tipos;
import util.Conexion;

/**
 *
 * @author MATT
 */
public class TiposRepository implements ITipos {

    @Override
    public List<Tipos> getAllTipos() {
        try
        {
            /*Crear el arreglo dinamico*/
            List<Tipos> lstTipos = new ArrayList<>();
            /*Llamar al Store Procedure*/
            CallableStatement ceTipos = Conexion.ObtenerConexion().prepareCall("{CALL USPListarTipos()}");
            ResultSet rsTipos = ceTipos.executeQuery();/*Asignando los datos de la BD a estructura de datos(ResultSet)*/
            while(rsTipos.next())    
            {
                Tipos objTipos = new Tipos();   
                objTipos.setIdTipo(Integer.parseInt(rsTipos.getString("idTipos")));
                objTipos.setTipo(rsTipos.getString("tipo"));
                
                lstTipos.add(objTipos);
            }
            return lstTipos;
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void addTipo(Tipos obj) {
        try
        {
            PreparedStatement stTipo = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarTipos(?)}"); //aqui toma solo los datos menos el id
            stTipo.setString(1, obj.getTipo());
            
            stTipo.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        } 
    }

    @Override
    public void removeTipo(Tipos obj) {
        try {
        System.out.println("ID del Tipo a eliminar (Repository): " + obj.getIdTipo());

        PreparedStatement stTipo = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarTipos(?)}");  //aqui toma solo el id
        stTipo.setInt(1, obj.getIdTipo());

        stTipo.executeUpdate(); // GRABAR EN LA BD
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateTipo(Tipos obj) {
        try
        {
            PreparedStatement stTipo = Conexion.ObtenerConexion().prepareStatement("{CALL USPModificarTipos(?,?)}"); //aqui toma el id y los demas datos
            stTipo.setInt(1,obj.getIdTipo());
            stTipo.setString(2, obj.getTipo());
            
            stTipo.executeUpdate(); //GRABAR EN LA BD
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
