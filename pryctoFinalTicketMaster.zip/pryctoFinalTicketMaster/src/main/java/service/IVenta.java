/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Ventas;

/**
 *
 * @author MATT
 */
public interface IVenta {
    List<Ventas> getAllVentas();
    List<Ventas> getVentaPorId(Ventas obj);
    void addVenta(Ventas obj);
    void removeVenta(Ventas obj);
    void updateVenta(Ventas obj);
}
