/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Conceptos;

import service.ConceptosRepository;


/**
 *
 * @author MATT
 */
public class ConceptosController {
    public List<Conceptos> getAllConceptosController()
    {
        return new ConceptosRepository().getAllConceptos();
    }
    
    public void addConceptoController(Conceptos obj)
    {
        new ConceptosRepository().addConcepto(obj);
    }
    public void removerConceptoController(Conceptos obj)
    {
        new ConceptosRepository().removeConcepto(obj);
    }
    public void updateConceptoController(Conceptos obj)
    {
        new ConceptosRepository().updateConcepto(obj);
    }
    
    public int getUltimoIdConceptoController() {
        List<Conceptos> listaConceptos = getAllConceptosController();

        if (!listaConceptos.isEmpty()) {
            Conceptos ultimoConcepto = listaConceptos.get(listaConceptos.size() - 1);
            return ultimoConcepto.getIdConcepto();
        } 
        else 
        {
            return 0; // o el valor predeterminado que desees si la lista está vacía
        }
    } 
}
