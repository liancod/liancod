/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Administradores;
import service.AdministradoresRepository;

/**
 *
 * @author MATT
 */
public class AdministradoresController {
    public List<Administradores> getAllAdministradoresController()
    {
        return new AdministradoresRepository().getAllAdministradores();
    }
    
    public void addAdministradoresController(Administradores obj)
    {
        new AdministradoresRepository().addAdministradores(obj);
    }
    
    public void removerAdministradoresController(Administradores obj)
    {
        new AdministradoresRepository().removeAdministradores(obj);
    }
    
    public void updateAdministradoresController(Administradores obj)
    {
        new AdministradoresRepository().updateAdministradores(obj);
    }
    
    public boolean verificarCredenciales(String usuario, String contrasena) {
        return new AdministradoresRepository().verificarCredenciales(usuario, contrasena);
    }
}
