/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Vendedores;
import service.VendedoresRepository;

/**
 *
 * @author MATT
 */
public class VendedoresController {
    public List<Vendedores> getAllVendedoresController()
    {
        return new VendedoresRepository().getAllVendedores();
    }
    
    public void addVendedoresController(Vendedores obj)
    {
        new VendedoresRepository().addVendedores(obj);
    }
    
    public void removerVendedoresController(Vendedores obj)
    {
        new VendedoresRepository().removeVendedores(obj);
    }
    
    public void updateVendedoresController(Vendedores obj)
    {
        new VendedoresRepository().updateVendedores(obj);
    }
    
    /*Esto me devuelve el ultimo id de la tabla*/
    public int getUltimoIdVendedorController() {
        List<Vendedores> listaVendedores = getAllVendedoresController();

        if (!listaVendedores.isEmpty())
        {
            Vendedores ultimoVendedor = listaVendedores.get(listaVendedores.size() - 1);
            return ultimoVendedor.getIdVendedores();
        } 
        else 
        {
            return 0; // o el valor predeterminado que desees si la lista está vacía
        }
    }
}
