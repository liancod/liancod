/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Tipos;
import service.TiposRepository;

/**
 *
 * @author MATT
 */
public class TiposController {
    public List<Tipos> getAllTiposController()
    {
        return new TiposRepository().getAllTipos();
    }
    
    public void addTipoController(Tipos obj)
    {
        new TiposRepository().addTipo(obj);
    }
    public void removerTipoController(Tipos obj)
    {
        new TiposRepository().removeTipo(obj);
    }
    public void updateTipoController(Tipos obj)
    {
        new TiposRepository().updateTipo(obj);
    }
    
    /*esto es para tener mi autogenerado en el Id, me permite tomar el ultimo valor(en cantidad)y restarle 1*/
    public int getUltimoIdTipoController() 
    {
        List<Tipos> listaTipos = getAllTiposController();

        if (!listaTipos.isEmpty()) {
            Tipos ultimoTipo = listaTipos.get(listaTipos.size() - 1);
            return ultimoTipo.getIdTipo();
        } 
        else {
            return 0; // o el valor predeterminado que desees si la lista está vacía
        }
    }
}
