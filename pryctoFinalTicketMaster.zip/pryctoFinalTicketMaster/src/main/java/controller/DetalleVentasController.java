/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.DetalleVentas;
import model.Ventas;
import service.DetalleVentasRepository;


/**
 *
 * @author MATT
 */
public class DetalleVentasController {
    public List<DetalleVentas> getAllDetalleVentasController()
    {
        return new DetalleVentasRepository().getAllDetalleVentas();
    }
    
    public List<DetalleVentas> getDetalleVentasPorIdController(DetalleVentas obj)
    {
        return new DetalleVentasRepository().getDetallesVentasPorId(obj);
    }

    public void addDetalleVentaController(DetalleVentas obj)
    {
        new DetalleVentasRepository().addDetalleVenta(obj);
    }
    
    public void removerDetalleVentaController(DetalleVentas obj)
    {
        new DetalleVentasRepository().removeDetalleVenta(obj);
    }
    
    public void updateFuncionController(DetalleVentas obj)
    {
        new DetalleVentasRepository().updateDetalleVenta(obj);
    }
    
    public int getUltimoIdVentaController() 
    {
        VentasController ventacontroller = new VentasController();
        List<Ventas> listaVentas = ventacontroller.getAllVentasController();

        if (!listaVentas.isEmpty()) {
            Ventas ultimoVenta = listaVentas.get(listaVentas.size() - 1);
            return ultimoVenta.getIdVenta();
        } 
        else {
            return 0; // o el valor predeterminado que desees si la lista está vacía
        }
    }
    
}
