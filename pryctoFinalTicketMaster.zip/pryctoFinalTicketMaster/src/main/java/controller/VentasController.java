/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Ventas;
import service.VentasRepository;


/**
 *
 * @author MATT
 */
public class VentasController {
    public List<Ventas> getAllVentasController()
    {
        return new VentasRepository().getAllVentas();
    }
    
    public List<Ventas> getVentaPorIdController(Ventas obj)
    {
        return new VentasRepository().getVentaPorId(obj);
    }
    
    public void addVentaController(Ventas obj)
    {
        new VentasRepository().addVenta(obj);
    }
    public void removerVentaController(Ventas obj)
    {
        new VentasRepository().removeVenta(obj);
    }
    public void updateVentaController(Ventas obj)
    {
        new VentasRepository().updateVenta(obj);
    }
    
    /*esto es para tener mi autogenerado en el Id, me permite tomar el ultimo valor(en cantidad)y restarle 1*/
    public int getUltimoIdVentaController() 
    {
        List<Ventas> listaVentas = getAllVentasController();

        if (!listaVentas.isEmpty()) {
            Ventas ultimoVenta = listaVentas.get(listaVentas.size() - 1);
            return ultimoVenta.getIdVenta();
        } 
        else {
            return 0; // o el valor predeterminado que desees si la lista está vacía
        }
    }
}
