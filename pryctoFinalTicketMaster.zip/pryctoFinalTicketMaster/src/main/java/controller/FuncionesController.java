/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Funciones;
import service.FuncionesRepository;


/**
 *
 * @author MATT
 */
public class FuncionesController {
    public List<Funciones> getAllFuncionesController()
    {
        return new FuncionesRepository().getAllFunciones();
    }
    
    public void addFuncionController(Funciones obj)
    {
        new FuncionesRepository().addFunciones(obj);
    }
    
    public void removerFuncionController(Funciones obj)
    {
        new FuncionesRepository().removeFunciones(obj);
    }
    
    public void updateFuncionController(Funciones obj)
    {
        new FuncionesRepository().updateFunciones(obj);
    }
    
    public List<Funciones> getFuncionesPorIdController(Funciones obj)
    {
        return new FuncionesRepository().getFuncionesPorId(obj);
    }
    
    public int getUltimoIdFuncionController() {
        List<Funciones> listaFunciones = getAllFuncionesController();

        if (!listaFunciones.isEmpty()) {
            Funciones ultimoFuncion = listaFunciones.get(listaFunciones.size() - 1);
            return ultimoFuncion.getIdFuncion();
        } 
        else 
        {
            return 0; // o el valor predeterminado que desees si la lista está vacía
        }
    }
}
