/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author MATT
 */
public class Ventas {
    private int idVenta;
    private int idVendedores;
    private String nombreVendedor;
    private double totalAPagar;
    private Date fechaDeVenta;
    
    //idVenta, idVendedores, nombreVendedor, totalAPagar, stock, fechaDeVenta

    public Ventas() {
    }

    public Ventas(int idVenta, int idVendedores, String nombreVendedor, double totalAPagar, Date fechaDeVenta) {
        this.idVenta = idVenta;
        this.idVendedores = idVendedores;
        this.nombreVendedor = nombreVendedor;
        this.totalAPagar = totalAPagar;
        this.fechaDeVenta = fechaDeVenta;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public int getIdVendedores() {
        return idVendedores;
    }

    public void setIdVendedores(int idVendedores) {
        this.idVendedores = idVendedores;
    }

    public String getNombreVendedor() {
        return nombreVendedor;
    }

    public void setNombreVendedor(String nombreVendedor) {
        this.nombreVendedor = nombreVendedor;
    }

    public double getTotalAPagar() {
        return totalAPagar;
    }

    public void setTotalAPagar(double totalAPagar) {
        this.totalAPagar = totalAPagar;
    }

    public Date getFechaDeVenta() {
        return fechaDeVenta;
    }

    public void setFechaDeVenta(Date fechaDeVenta) {
        this.fechaDeVenta = fechaDeVenta;
    }
    
    
    
    
}