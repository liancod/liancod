/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author MATT
 */
public class Vendedores {
    private int idVendedores;
    private String nombreVendedores;

    public Vendedores() {
    }

    public Vendedores(int idVendedores, String nombreVendedores) {
        this.idVendedores = idVendedores;
        this.nombreVendedores = nombreVendedores;
    }

    public int getIdVendedores() {
        return idVendedores;
    }

    public void setIdVendedores(int idVendedores) {
        this.idVendedores = idVendedores;
    }

    public String getNombreVendedores() {
        return nombreVendedores;
    }

    public void setNombreVendedores(String nombreVendedores) {
        this.nombreVendedores = nombreVendedores;
    }
    
    
}
