/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author MATT
 */
public class Conceptos {
    //idConcepto,concepto_nombre,idTipo
    private int idConcepto;
    private String concepto_nombre;

    public Conceptos() {
    }

    public Conceptos(int idConcepto, String concepto_nombre) {
        this.idConcepto = idConcepto;
        this.concepto_nombre = concepto_nombre;
    }

    public int getIdConcepto() {
        return idConcepto;
    }

    public void setIdConcepto(int idConcepto) {
        this.idConcepto = idConcepto;
    }

    public String getConcepto_nombre() {
        return concepto_nombre;
    }

    public void setConcepto_nombre(String concepto_nombre) {
        this.concepto_nombre = concepto_nombre;
    }
    
    
    
}