/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author MATT
 */
public class Administradores {
    private int idAdmin;
    private String admin_nick;
    private String admin_password;

    public Administradores() {
    }

    public Administradores(int idAdmin, String admin_nick, String admin_password) {
        this.idAdmin = idAdmin;
        this.admin_nick = admin_nick;
        this.admin_password = admin_password;
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }

    public String getAdmin_nick() {
        return admin_nick;
    }

    public void setAdmin_nick(String admin_nick) {
        this.admin_nick = admin_nick;
    }

    public String getAdmin_password() {
        return admin_password;
    }

    public void setAdmin_password(String admin_password) {
        this.admin_password = admin_password;
    }
    
    
    
}
