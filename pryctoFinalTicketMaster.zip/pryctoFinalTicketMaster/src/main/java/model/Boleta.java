/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author MATT
 */
public class Boleta {
    private int idVenta;
    private String nombreFuncion;
    private String conceptoNombre;
    private String nombreVendedores;
    private double precio;
    private int cantidad;
    private double totalAPagar;
    private String nombreCliente;
    private String dniCliente;
    private Date fechaDeVenta;

    public Boleta() {
    }

    public Boleta(int idVenta, String nombreFuncion, String conceptoNombre, String nombreVendedores, double precio, int cantidad, double totalAPagar, String nombreCliente, String dniCliente, Date fechaDeVenta) {
        this.idVenta = idVenta;
        this.nombreFuncion = nombreFuncion;
        this.conceptoNombre = conceptoNombre;
        this.nombreVendedores = nombreVendedores;
        this.precio = precio;
        this.cantidad = cantidad;
        this.totalAPagar = totalAPagar;
        this.nombreCliente = nombreCliente;
        this.dniCliente = dniCliente;
        this.fechaDeVenta = fechaDeVenta;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getNombreFuncion() {
        return nombreFuncion;
    }

    public void setNombreFuncion(String nombreFuncion) {
        this.nombreFuncion = nombreFuncion;
    }

    public String getConceptoNombre() {
        return conceptoNombre;
    }

    public void setConceptoNombre(String conceptoNombre) {
        this.conceptoNombre = conceptoNombre;
    }

    public String getNombreVendedores() {
        return nombreVendedores;
    }

    public void setNombreVendedores(String nombreVendedores) {
        this.nombreVendedores = nombreVendedores;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotalAPagar() {
        return totalAPagar;
    }

    public void setTotalAPagar(double totalAPagar) {
        this.totalAPagar = totalAPagar;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getDniCliente() {
        return dniCliente;
    }

    public void setDniCliente(String dniCliente) {
        this.dniCliente = dniCliente;
    }

    public Date getFechaDeVenta() {
        return fechaDeVenta;
    }

    public void setFechaDeVenta(Date fechaDeVenta) {
        this.fechaDeVenta = fechaDeVenta;
    }
    
    
    
}
