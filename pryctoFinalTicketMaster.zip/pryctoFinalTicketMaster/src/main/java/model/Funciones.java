/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author MATT
 */
public class Funciones {
    //idFuncion,idConcepto,conceptoNombre,nombreFuncion,idTipos,tipoNombre,lugarFuncion,fechaFuncion,disponibleFuncion,precio
    private int idFuncion;
    private int idConcepto;
    private String conceptoNombre;
    private String nombreFuncion;
    private int idTipos;
    private String tipoNombre;
    private String lugarFuncion;
    private Date fechaFuncion;
    private String disponibleFuncion;
    private double precio;

    public Funciones() {
    }

    public Funciones(int idFuncion, int idConcepto, String conceptoNombre, String nombreFuncion, int idTipos, String tipoNombre, String lugarFuncion, Date fechaFuncion, String disponibleFuncion, double precio) {
        this.idFuncion = idFuncion;
        this.idConcepto = idConcepto;
        this.conceptoNombre = conceptoNombre;
        this.nombreFuncion = nombreFuncion;
        this.idTipos = idTipos;
        this.tipoNombre = tipoNombre;
        this.lugarFuncion = lugarFuncion;
        this.fechaFuncion = fechaFuncion;
        this.disponibleFuncion = disponibleFuncion;
        this.precio = precio;
    }

    public int getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }

    public int getIdConcepto() {
        return idConcepto;
    }

    public void setIdConcepto(int idConcepto) {
        this.idConcepto = idConcepto;
    }

    public String getConceptoNombre() {
        return conceptoNombre;
    }

    public void setConceptoNombre(String conceptoNombre) {
        this.conceptoNombre = conceptoNombre;
    }

    public String getNombreFuncion() {
        return nombreFuncion;
    }

    public void setNombreFuncion(String nombreFuncion) {
        this.nombreFuncion = nombreFuncion;
    }

    public int getIdTipos() {
        return idTipos;
    }

    public void setIdTipos(int idTipos) {
        this.idTipos = idTipos;
    }

    public String getTipoNombre() {
        return tipoNombre;
    }

    public void setTipoNombre(String tipoNombre) {
        this.tipoNombre = tipoNombre;
    }

    public String getLugarFuncion() {
        return lugarFuncion;
    }

    public void setLugarFuncion(String lugarFuncion) {
        this.lugarFuncion = lugarFuncion;
    }

    public Date getFechaFuncion() {
        return fechaFuncion;
    }

    public void setFechaFuncion(Date fechaFuncion) {
        this.fechaFuncion = fechaFuncion;
    }

    public String getDisponibleFuncion() {
        return disponibleFuncion;
    }

    public void setDisponibleFuncion(String disponibleFuncion) {
        this.disponibleFuncion = disponibleFuncion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
}
